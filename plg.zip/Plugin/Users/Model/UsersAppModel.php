<?php

/**
 * @package Croogo.Users.Model
 */
class UsersAppModel extends AppModel {

}
