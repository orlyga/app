<?php
class UserData {

	public $table = 'users';

	public $records = array(
	);

}
