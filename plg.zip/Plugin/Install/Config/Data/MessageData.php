<?php
class MessageData {

	public $table = 'messages';

	public $records = array(
	);

}
