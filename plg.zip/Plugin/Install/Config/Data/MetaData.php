<?php
class MetaData {

	public $table = 'meta';

	public $records = array(
		array(
			'id' => '1',
			'model' => 'Node',
			'foreign_key' => '1',
			'key' => 'meta_keywords',
			'value' => 'key1, key2',
			'weight' => ''
		),
	);

}
