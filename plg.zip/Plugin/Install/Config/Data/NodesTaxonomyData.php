<?php
class NodesTaxonomyData {

	public $table = 'nodes_taxonomies';

	public $records = array(
		array(
			'id' => '1',
			'node_id' => '1',
			'taxonomy_id' => '1'
		),
	);

}
