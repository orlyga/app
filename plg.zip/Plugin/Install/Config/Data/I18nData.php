<?php
class I18nData {

	public $table = 'i18n';

	public $records = array(
	);

}
