<?php
class CommentData {

	public $table = 'comments';

	public $records = array(
		array(
			'id' => '1',
			'parent_id' => '',
			'node_id' => '1',
			'user_id' => '0',
			'name' => 'Mr Croogo',
			'email' => 'email@example.com',
			'website' => 'http://www.croogo.org',
			'ip' => '127.0.0.1',
			'title' => '',
			'body' => 'Hi, this is the first comment.',
			'rating' => '',
			'status' => '1',
			'notify' => '0',
			'type' => 'blog',
			'comment_type' => 'comment',
			'lft' => '1',
			'rght' => '2',
			'updated' => '2009-12-25 12:00:00',
			'created' => '2009-12-25 12:00:00'
		),
	);

}
