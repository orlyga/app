<?php

/**
 * @package Croogo.Meta.Model
 */
class MetaAppModel extends AppModel {

}
