<?php

/**
 * @package Croogo.Users.Model
 */
class GroupsAppModel extends AppModel {

}
