<?php

CroogoRouter::connect('/example/route/here', array('plugin' => 'example', 'controller' => 'example', 'action' => 'index'));
