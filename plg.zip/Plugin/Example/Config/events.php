<?php

$config = array(
	'EventHandlers' => array(
		'Example.ExampleEventHandler' => array(
			'options' => array(
				'priority' => 1,
			),
		),
	),
);
