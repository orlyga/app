<?php

App::uses('AppController', 'Controller');

/**
 * Blocks App Controller
 *
 * PHP version 5
 *
 * @category Blocks.Controller
 * @package  Croogo.Blocks.Controller
 * @version  1.0
 * @author   Fahad Ibnay Heylaal <contact@fahad19.com>
 * @license  http://www.opensource.org/licenses/mit-license.php The MIT License
 * @link     http://www.croogo.org
 */
class BlocksAppController extends AppController {

}
