<?php

Croogo::hookBehavior('Order', 'Suppliers.SuppliersOrderMonitor');
