<?php

App::uses('AppModel', 'Model');

class Order extends AppModel {

	public $useTable = false;

}
