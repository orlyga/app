<?php

Croogo::hookHelper('*', 'Wysiwyg.Wysiwyg');

Croogo::hookComponent('Attachments', 'Wysiwyg.Wysiwyg');