<?php
/*Gmail component setup in cakephp by Shaharia Azam (shaharia.azam@gmail.com)*/
class EmailConfig {
    public $gmail = array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => 465,
        'username' => 'artbyorly@gmail.com',
        'password' => 'gazit123',
        'transport' => 'Smtp'
    );
}
?>