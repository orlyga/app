<?php 
/*$production = array(
    'Facebook' => array(
        'appId'  => '485827148161257',
        'apiKey' => '485827148161257',
        'secret' => 'dd4d1508c11946efbd6ce5dcfdc0bb85',
        'cookie' => true,
        'locale' => 'he_IL',
    )
);*/

$config = array(
    'Facebook' => array(
        'appId'  => '485827148161257',
        'apiKey' => '485827148161257',
        'secret' => 'dd4d1508c11946efbd6ce5dcfdc0bb85',
        'cookie' => true,
        'locale' => 'he_IL',
    )
);
?>