<?php

App::uses('CroogoAppHelper', 'Croogo.View/Helper');

/**
 * Base Application Helper
 *
 * @package  Croogo
 * @link     http://www.croogo.org
 */
class AppHelper extends CroogoAppHelper {

}
