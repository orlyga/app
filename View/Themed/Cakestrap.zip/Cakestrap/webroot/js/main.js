
var app = angular.module( "Kshurim", [] );

   app.controller(
            "AppController",
            function( $scope ) {
 
               
 $scope.ajaxCall=function(){
 	 $('#ajaxContent').load($(this).attr('href'), onSuccess);
    return false;
	}
          
$scope.ajaxFailed= function(text){
	if(text=='Forbidden'){
		window.location="/";
	}
}
});

/*$(function(){
	//$('.ajax-link').delegate('click', onClick);

               $( "#dialog" ).dialog({
               	height:140,
               	modal:true,
               	autoOpen: false,
            	show: "blind",
            	hide: "explode"
               });
            	

});*/